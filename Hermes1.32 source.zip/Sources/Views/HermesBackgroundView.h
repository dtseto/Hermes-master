//
//  HermesBackgroundView.h
//  Hermes
//
//  Created by Nicholas Riley on 9/9/16.
//
//

#import <Cocoa/Cocoa.h>

@interface HermesBackgroundView : NSView

@end
