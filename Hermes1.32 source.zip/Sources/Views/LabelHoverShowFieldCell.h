//
//  LabelHoverShowFieldCell.h
//  Hermes
//
//  Created by Nicholas Riley on 5/22/16.
//
//

#import <Cocoa/Cocoa.h>

@interface LabelHoverShowFieldCell : NSTextFieldCell

@end
