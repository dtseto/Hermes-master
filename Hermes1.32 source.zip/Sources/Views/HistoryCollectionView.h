//
//  HistoryCollectionView.h
//  Hermes
//
//  Created by Winston Weinert on 1/1/14.
//
//

#import <Cocoa/Cocoa.h>

@interface HistoryCollectionView : NSCollectionView

@end
