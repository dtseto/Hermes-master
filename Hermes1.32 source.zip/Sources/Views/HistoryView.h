//
//  HistoryView.h
//  Hermes
//
//  Created by Alex Crichton on 6/29/12.
//

@interface HistoryView : NSView

@property BOOL selected;

@end
