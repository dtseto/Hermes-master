//
//  MusicProgressSliderCell.h
//  Hermes
//
//  Created by Xinhong LIU on 19/4/15.
//
//

#import <Cocoa/Cocoa.h>

@interface MusicProgressSliderCell : NSSliderCell

@end
