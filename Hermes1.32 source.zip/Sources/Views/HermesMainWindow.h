//
//  HermesMainWindow.h
//  Hermes
//
//  Created by Nicholas Riley on 9/10/16.
//
//

#import <Cocoa/Cocoa.h>

@interface HermesMainWindow : NSWindow

@end
