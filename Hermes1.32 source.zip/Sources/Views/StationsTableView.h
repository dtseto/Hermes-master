//
//  StationsTableView.h
//  Hermes
//
//  Created by Nicholas Riley on 9/14/13.
//
//

#import <Cocoa/Cocoa.h>

@interface StationsTableView : NSTableView
{
  IBOutlet NSButton *playButton;
}

@end
