//
//  HistoryItem.h
//  Hermes
//
//  Created by Alex Crichton on 10/10/11.
//

@interface HistoryItem : NSCollectionViewItem {
  NSButton *art;
}
@end
