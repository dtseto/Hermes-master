//
//  HermesApp.h
//  Hermes
//
//  Created by Nicholas Riley on 4/1/14.
//
//

#import <Cocoa/Cocoa.h>

@interface HermesApp : NSApplication

@end
