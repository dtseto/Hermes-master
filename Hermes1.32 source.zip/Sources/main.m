//
//  main.m
//  Pithos
//
//  Created by Alex Crichton on 3/11/11.
//

int main(int argc, char *argv[]) {
  return NSApplicationMain(argc,  (const char **) argv);
}
